#!/usr/bin/env python3
"""Render a least-egress policy for SBOM service and regional S3 addresses.

Requires an authenticated AWS CLI and Python stdlib only. The generated
NetworkPolicy allows DNS, the in-cluster Postgres service, and HTTPS only to
the AWS-managed regional S3 prefix list. It does not allow general public
egress or metadata-service access.
"""

from __future__ import annotations

import ipaddress
import json
import os
import subprocess
import sys


def aws_json(*args: str) -> dict:
    result = subprocess.run(
        ["aws", *args, "--output", "json"],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


def main() -> int:
    region = os.environ.get("AWS_REGION", "ap-south-1")
    service_name = f"com.amazonaws.{region}.s3"
    prefixes = aws_json(
        "ec2", "describe-prefix-lists", "--region", region,
        "--filters", "Name=prefix-list-name,Values=" + service_name,
    ).get("PrefixLists", [])
    matching = [item for item in prefixes if item.get("PrefixListName") == service_name]
    if len(matching) != 1 or not matching[0].get("PrefixListId"):
        raise RuntimeError(f"expected one managed prefix list for {service_name}")
    prefix_id = matching[0]["PrefixListId"]
    entries = aws_json(
        "ec2", "get-managed-prefix-list-entries", "--region", region,
        "--prefix-list-id", prefix_id,
    ).get("Entries", [])
    cidrs = sorted({
        str(ipaddress.ip_network(entry["Cidr"], strict=True))
        for entry in entries
        if ":" not in entry.get("Cidr", "")
    })
    if not cidrs:
        raise RuntimeError("regional S3 prefix list contains no IPv4 ranges")

    print("apiVersion: networking.k8s.io/v1")
    print("kind: NetworkPolicy")
    print("metadata:")
    print("  name: phantom-sbom-restricted-egress")
    print("  namespace: phantom")
    print("spec:")
    print("  podSelector:")
    print("    matchLabels:")
    print("      app: phantom-sbom-service")
    print("  policyTypes: [Egress]")
    print("  egress:")
    print("    - to:")
    print("        - namespaceSelector:")
    print("            matchLabels:")
    print("              kubernetes.io/metadata.name: kube-system")
    print("      ports:")
    print("        - {protocol: UDP, port: 53}")
    print("        - {protocol: TCP, port: 53}")
    print("    - to:")
    print("        - podSelector:")
    print("            matchLabels:")
    print("              app: phantom-postgres")
    print("      ports:")
    print("        - {protocol: TCP, port: 5432}")
    print("    - to:")
    for cidr in cidrs:
        print("        - ipBlock:")
        print(f"            cidr: {cidr}")
    print("      ports:")
    print("        - {protocol: TCP, port: 443}")
    print(f"# AWS managed prefix list: {prefix_id} ({service_name}); IPv4 CIDRs: {len(cidrs)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, subprocess.CalledProcessError, json.JSONDecodeError) as exc:
        print(f"cannot render restricted S3 egress policy: {exc}", file=sys.stderr)
        raise SystemExit(2) from exc
