"""
phantom-core test package.
"""
